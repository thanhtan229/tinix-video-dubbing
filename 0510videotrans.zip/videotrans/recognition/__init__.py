import importlib
import inspect
from typing import Union, List, Dict
from pathlib import Path
from videotrans.configure.config import tr, settings, params, app_cfg, logger, ROOT_DIR
from videotrans.recognition._base import BaseRecogn
from videotrans import winform

FASTER_WHISPER = 0
OPENAI_WHISPER = 1
QWENASR = 2
FUNASR_CN = 3
HUGGINGFACE_ASR = 4

OPENAI_API = 5
GEMINI_SPEECH = 6
QWEN3ASR = 7
ZIJIE_RECOGN_MODEL = 8

ZHIPU_API = 9

Deepgram = 10

PARAKEET = 11
Whisper_CPP = 12
Faster_Whisper_XXL = 13
WHISPERX_API = 14

AI_302 = 15
ElevenLabs = 16

GOOGLE_SPEECH = 17

STT_API = 18
WHISPER_NET = 19
CAMB_ASR = 20
CUSTOM_API = 21

_ID_NAME_DICT = {
    FASTER_WHISPER: tr("Faster-whisper"),
    OPENAI_WHISPER: tr("OpenAI-whisper"),
    QWENASR: f'Qwen-ASR({tr("Local")})',
    FUNASR_CN: tr("FunASR-Chinese"),
    HUGGINGFACE_ASR: 'Huggingface_ASR',

    OPENAI_API: tr("OpenAI Speech to Text"),
    GEMINI_SPEECH: tr("Gemini AI"),

    QWEN3ASR: tr("Ali Qwen3-ASR"),
    ZIJIE_RECOGN_MODEL: tr("VolcEngine STT"),
    ZHIPU_API: f'{tr("Zhipu AI")} GLM-ASR',

    Deepgram: "Deepgram.com",

    PARAKEET: "Parakeet-tdt",

    Whisper_CPP: "Whisper.cpp",
    Faster_Whisper_XXL: "Faster-Whisper-XXL.exe",
    WHISPERX_API: "WhisperX",

    AI_302: "302.AI",
    ElevenLabs: "ElevenLabs.io",
    GOOGLE_SPEECH: tr("Google Speech to Text"),
    STT_API: tr("STT Speech API"),
    WHISPER_NET: "Whisper.NET",
    CAMB_ASR: "CAMB AI",
    CUSTOM_API: tr("Custom API"),
}
RECOGN_NAME_LIST = list(_ID_NAME_DICT.values())

# 渠道id对应的设置窗口和sk键名, key_name: 存储SK或api url的键，(app_cfg.params),win:对应winform中的映射
_CLS_DICT = {
    STT_API: {"key_name": "stt_url", "win": "sttapi"},
    PARAKEET: {"key_name": "parakeet_address", "win": "parakeet"},
    QWEN3ASR: {"key_name": "qwenmt_key", "win": "qwenmt"},
    CUSTOM_API: {"key_name": "recognapi_url", "win": "recognapi"},
    OPENAI_API: {"key_name": "openairecognapi_key", "win": "openairecognapi"},
    ZIJIE_RECOGN_MODEL: {"key_name": "zijierecognmodel_appid", "win": "zijierecognmodel"},  # 字节语音识别大模型极速版
    Deepgram: {"key_name": "deepgram_apikey", "win": "deepgram"},
    GEMINI_SPEECH: {"key_name": "gemini_key", "win": "gemini"},
    AI_302: {"key_name": "ai302_key", "win": "ai302"},
    ElevenLabs: {"key_name": "elevenlabstts_key", "win": "elevenlabs"},
    ZHIPU_API: {"key_name": "zhipu_key", "win": "zhipuai"},
    CAMB_ASR: {"key_name": "camb_api_key", "win": "cambtts"},
}
HUGGINGFACE_ASR_MODELS = {
    "nvidia/parakeet-ctc-1.1b": ['en'],

    # hub
    "reazon-research/japanese-wav2vec2-large-rs35kh": ['ja'],
    # pipeline whisper
    "kotoba-tech/kotoba-whisper-v2.0": ['ja'],

    # pipeline whisper
    "biodatlab/whisper-th-large-v3": ['th'],
    "vinai/Phowhisper-large": ['vi'],

    "openai/whisper-large-v3": [],
    # "openai/whisper-tiny":[],
    # "Systran/faster-whisper-tiny":[]

}
try:
    if Path(f'{ROOT_DIR}/huggingface_models.txt').exists():
        for it in Path(f'{ROOT_DIR}/huggingface_models.txt').read_text(encoding='utf-8').strip().split("\n"):
            HUGGINGFACE_ASR_MODELS[it] = []
except Exception as e:
    logger.waring(f'添加自定义 Huggingface_ASR 模型失败:{e}')

_module_map = {
    FASTER_WHISPER: "._whisper",
    OPENAI_WHISPER: "._whisper",
    QWENASR: "._qwenasrlocal",
    FUNASR_CN: "._funasr",
    HUGGINGFACE_ASR: "._huggingface",
    OPENAI_API: "._openairecognapi",
    GEMINI_SPEECH: "._gemini",
    QWEN3ASR: "._qwen3asr",
    ZIJIE_RECOGN_MODEL: "._zijiemodel",
    ZHIPU_API: "._glmasr",
    Deepgram: "._deepgram",
    PARAKEET: "._parakeet",
    Whisper_CPP: "._cpp", #通过subprocess直接调用
    Faster_Whisper_XXL: "._xxl",#通过subprocess直接调用
    WHISPERX_API: "._whisperx",
    AI_302: "._ai302",
    ElevenLabs: "._elevenlabs",
    GOOGLE_SPEECH: "._google",
    STT_API: "._stt",
    WHISPER_NET: "._whispernet",
    CAMB_ASR: "._camb",
    CUSTOM_API: "._recognapi",
}
_loaded_modules = {}


def _get_instance(name: int = 0):
    """
    获取模块，提取出里面的子类，并返回实例化对象
    """
    if name in _loaded_modules:
        return _loaded_modules[name]

    if name not in _module_map:
        raise AttributeError(f"No winform module named '{name}' found.")

    try:
        # 2. 动态导入模块
        module = importlib.import_module(_module_map[name], __name__)

        # 3. 使用 inspect 遍历模块里的所有类
        for obj_name, obj in inspect.getmembers(module, inspect.isclass):

            # 判断条件：
            # 1. 是 BaseWindow 的子类
            # 2. 不是 BaseWindow 本身
            # 3. 确实是写在这个文件里的（防止抓到 import 进来的其他子类）
            if issubclass(obj, BaseRecogn) and obj is not BaseRecogn and obj.__module__ == module.__name__:
                # 4. 找到目标类，存入缓存，并直接返回类（注意这里是 obj，没有括号！）
                _loaded_modules[name] = obj
                return obj

        # 如果遍历完没找到符合条件的类
        raise AttributeError(f"Module '{name}' contains no subclass of BaseWindow.")

    except ImportError as e:
        raise ImportError(f"Could not import winform module '{name}': {e}")


# 判断所用渠道和模型是否支持该语言的语音识别
# langcode=语言代码，recogn_type=识别渠道,model_name=模型名字
def is_allow_lang(langcode: str = None, recogn_type: int = None, model_name=None):
    # faster-whisper/openai-whisper支持所有语言
    if recogn_type in [FASTER_WHISPER, OPENAI_WHISPER, WHISPERX_API, Faster_Whisper_XXL, Whisper_CPP, OPENAI_API,
                       AI_302, GEMINI_SPEECH, WHISPER_NET]:
        return True
    # huggingface_asr 渠道里的 openai 和 Systran 模型也支持所有语言
    if recogn_type == HUGGINGFACE_ASR and not HUGGINGFACE_ASR_MODELS.get(model_name):
        return True
    if recogn_type == HUGGINGFACE_ASR and HUGGINGFACE_ASR_MODELS.get(model_name):
        if langcode not in HUGGINGFACE_ASR_MODELS[model_name]:
            return tr("Only support") + tr(HUGGINGFACE_ASR_MODELS[model_name])
        return True
    if (langcode == 'auto' or not langcode) and recogn_type not in [FASTER_WHISPER, OPENAI_WHISPER, GEMINI_SPEECH,
                                                                    ElevenLabs, Faster_Whisper_XXL, Whisper_CPP,
                                                                    WHISPERX_API, AI_302, OPENAI_API, WHISPER_NET]:
        return tr("Recognition language is only supported in faster-whisper or openai-whisper or Gemini  modes.")

    return True


# 自定义识别、openai-api识别、zh_recogn识别是否填写了相关信息和sk等
# 正确返回True，失败返回False，并弹窗
def is_input_api(recogn_type: int = None, return_str=False):
    _cls = _CLS_DICT.get(recogn_type)
    if not _cls:
        return True
    if _cls and not params.get(_cls.get('key_name')):
        return "Please configure the API Key information of the Deepgram channel first." if return_str else winform.get_win(
            _cls.get('win'))
    return True


# 统一入口
def run(*,
        detect_language=None,
        audio_file=None,
        cache_folder=None,
        model_name=None,
        uuid=None,
        recogn_type: int = 0,
        is_cuda=None,
        subtitle_type=0,
        max_speakers=-1,  # -1 不启用说话人识别,0=不限制数量，>0最大数量
        llm_post=False,
        recogn2pass=False  # 二次对配音文件识别，生成简短字幕

        ) -> Union[List[Dict], None]:
    if app_cfg.exit_soft or (uuid and uuid in app_cfg.stoped_uuid_set):
        return
    kwargs = {
        "detect_language": detect_language,
        "audio_file": audio_file,
        "cache_folder": cache_folder,
        "model_name": model_name,
        "uuid": uuid,
        "is_cuda": is_cuda,
        "subtitle_type": subtitle_type,
        "recogn_type": recogn_type,
        "max_speakers": max_speakers,
        "llm_post": llm_post,
        "recogn2pass": recogn2pass
    }
    logger.debug(f'[recognition]__init__:{kwargs=}')

    _cls: Union[BaseRecogn, None] = _get_instance(recogn_type)
    if not _cls:
        raise RuntimeError(f'No this Recognition Channel:{recogn_type=}')

    return _cls(**kwargs).run()
