# videotrans/util/tools.pyi
# 这个文件只用于类型检查和IDE支持，运行时不会被Python解释器执行。
# 我们在这里明确地导入所有函数，以便PyCharm能够识别它们。


from .help_misc import *
from .help_ffmpeg import *
from .help_srt import *
from .help_role import *
from .help_down import *

