# 数字代表界面中的显示顺序
import copy
from typing import Union
import inspect
import importlib
from videotrans.configure.config import tr, params, settings, app_cfg, logger
from videotrans.tts._base import BaseTTS
from videotrans import winform

# 推荐
EDGE_TTS = 0
QWEN3LOCAL_TTS = 1
OMNIVOICE_TTS = 2
PIPER_TTS = 3
VITSCNEN_TTS = 4

# 本地
GPTSOVITS_TTS = 5
F5_TTS = 6
INDEX_TTS = 7
COSYVOICE_TTS = 8
Supertonic_TTS = 9
VOXCPM_TTS = 10
CHATTERBOX_TTS = 11

# 云api
DOUBAO2_TTS = 12
QWEN_TTS = 13
XIAOMI_TTS = 14
GLM_TTS = 15
MINIMAXI_TTS = 16

# 海外
OPENAI_TTS = 17
GEMINI_TTS = 18
ELEVENLABS_TTS = 19
XAI_TTS = 20
AZURE_TTS = 21

AI302_TTS = 22

# 本地
CHATTTS = 23
SPARK_TTS = 24
DIA_TTS = 25
KOKORO_TTS = 26
CLONE_VOICE_TTS = 27
FISHTTS = 28

#
GOOGLE_TTS = 29
CAMB_TTS = 30
MOSS_TTS = 31

FreeAzure = 32
TTS_API = 33

# 支持克隆的渠道
SUPPORT_CLONE = [
    COSYVOICE_TTS,
    CLONE_VOICE_TTS,
    F5_TTS, INDEX_TTS,
    VOXCPM_TTS,
    SPARK_TTS,
    DIA_TTS,
    CHATTERBOX_TTS,
    GPTSOVITS_TTS,
    QWEN3LOCAL_TTS,
    CAMB_TTS,
    OMNIVOICE_TTS,
    MOSS_TTS
]
_ID_NAME_DICT = {
    EDGE_TTS: tr("Edge-TTS(free)"),
    QWEN3LOCAL_TTS: f"Qwen3-TTS({tr('Local')}{tr('Built-in')})",
    OMNIVOICE_TTS: f"OmniVoice({tr('Local')}API)",
    PIPER_TTS: f"Piper({tr('Local')}{tr('Built-in')})",
    VITSCNEN_TTS: f"VITS({tr('Local')}{tr('Built-in')})",

    DOUBAO2_TTS: tr("DouBao2"),
    QWEN_TTS: "Qwen3-TTS",
    XIAOMI_TTS: 'XiaoMi-TTS',
    GLM_TTS: f'GLM-TTS {tr("Zhipu AI")}',
    MINIMAXI_TTS: "Minimaxi-TTS",

    GPTSOVITS_TTS: f"GPT-SoVITS({tr('Local')}API)",
    F5_TTS: f"F5-TTS({tr('Local')}API)",
    INDEX_TTS: f"Index-TTS({tr('Local')}API)",
    COSYVOICE_TTS: f"CosyVoice({tr('Local')}API)",
    Supertonic_TTS: f"Supertonic({tr('Local')}{tr('Built-in')})",
    VOXCPM_TTS: f"VoxCPM({tr('Local')}API)",
    CHATTERBOX_TTS: f"ChatterBox({tr('Local')}API)",

    OPENAI_TTS: "OpenAI-TTS",
    GEMINI_TTS: "Gemini TTS",
    ELEVENLABS_TTS: "Elevenlabs.io",
    XAI_TTS: 'X.AI TTS',
    AZURE_TTS: "Azure-TTS",

    AI302_TTS: "302.AI",

    CHATTTS: f"ChatTTS({tr('Local')}API)",
    SPARK_TTS: f"Spark-TTS({tr('Local')}API)",
    DIA_TTS: f"Dia-TTS({tr('Local')}API)",
    KOKORO_TTS: f"kokoro-TTS({tr('Local')}API)",
    CLONE_VOICE_TTS: f"clone-voice({tr('Local')}API)",
    FISHTTS: f"Fish-TTS({tr('Local')}API)",

    GOOGLE_TTS: "gTTS(free)",
    CAMB_TTS: "CAMB AI TTS",
    MOSS_TTS: "MOSS-TTS-Nano",

    FreeAzure: tr('Azure(free)'),
    TTS_API: tr("Customize API"),
}

TTS_NAME_LIST = list(_ID_NAME_DICT.values())

# 渠道id对应的设置窗口和sk键名, key_name: 存储SK或api url的键，(app_cfg.params),win:对应winform中的映射
_CLS_DICT = {
    OPENAI_TTS: {"key_name": "openaitts_key", "win": "openaitts"},
    QWEN_TTS: {"key_name": "qwentts_key", "win": "qwentts"},
    XAI_TTS: {"key_name": "xaitts_key", "win": "xaitts"},
    XIAOMI_TTS: {"key_name": "xiaomi_key", "win": "mitts"},
    MINIMAXI_TTS: {"key_name": "minimaxi_apikey", "win": "minimaxi"},
    KOKORO_TTS: {"key_name": "kokoro_api", "win": "kokoro"},
    AI302_TTS: {"key_name": "ai302_key", "win": "ai302"},
    CLONE_VOICE_TTS: {"key_name": "clone_api", "win": "clone"},
    ELEVENLABS_TTS: {"key_name": "elevenlabstts_key", "win": "elevenlabs"},
    TTS_API: {"key_name": "ttsapi_url", "win": "ttsapi"},
    GPTSOVITS_TTS: {"key_name": "gptsovits_url", "win": "gptsovits"},
    CHATTERBOX_TTS: {"key_name": "chatterbox_url", "win": "chatterbox"},
    COSYVOICE_TTS: {"key_name": "cosyvoice_url", "win": "cosyvoice"},
    OMNIVOICE_TTS: {"key_name": "omnivoice_url", "win": "omnivoice"},
    FISHTTS: {"key_name": "fishtts_url", "win": "fishtts"},
    CHATTTS: {"key_name": "chattts_api", "win": "chattts"},
    AZURE_TTS: {"key_name": "azure_speech_key", "win": "azuretts"},
    GEMINI_TTS: {"key_name": "gemini_key", "win": "gemini"},
    DOUBAO2_TTS: {"key_name": "doubao2_access", "win": "doubao2"},
    CAMB_TTS: {"key_name": "camb_api_key", "win": "cambtts"},
    MOSS_TTS: {"key_name": "moss_tts_url", "win": "mosstts"},
    GLM_TTS: {"key_name": "zhipu_key", "win": "zhipuai"},
    F5_TTS: {"key_name": "f5tts_url", "win": "f5tts"},
    INDEX_TTS: {"key_name": "indextts_url", "win": "f5tts"},
    SPARK_TTS: {"key_name": "sparktts_url", "win": "f5tts"},
    VOXCPM_TTS: {"key_name": "voxcpmtts_url", "win": "f5tts"},
    DIA_TTS: {"key_name": "diatts_url", "win": "f5tts"},
}

_module_map = {
    EDGE_TTS: "._edgetts",
    QWEN3LOCAL_TTS: "._qwenttslocal",
    OMNIVOICE_TTS: "._omnivoice",
    PIPER_TTS: "._piper",
    VITSCNEN_TTS: "._vits",
    QWEN_TTS: "._qwentts",
    DOUBAO2_TTS: "._doubao2",
    GLM_TTS: "._glmtts",
    GPTSOVITS_TTS: "._gptsovits",
    F5_TTS: "._f5tts",
    INDEX_TTS: "._f5tts",
    COSYVOICE_TTS: "._cosyvoice",
    Supertonic_TTS: "._supertonic",
    MINIMAXI_TTS: "._minimaxi",
    OPENAI_TTS: "._openaitts",
    AI302_TTS: "._ai302tts",
    ELEVENLABS_TTS: "._elevenlabs",
    AZURE_TTS: "._azuretts",
    GEMINI_TTS: "._geminitts",
    VOXCPM_TTS: "._f5tts",
    CHATTERBOX_TTS: "._qwenttslocal",
    CHATTTS: "._qwenttslocal",
    SPARK_TTS: "._f5tts",
    DIA_TTS: "._f5tts",
    KOKORO_TTS: "._kokoro",
    CLONE_VOICE_TTS: "._clone",
    FISHTTS: "._fishtts",
    FreeAzure: "._freeazure",
    GOOGLE_TTS: "._gtts",
    XAI_TTS: "._xaitts",
    XIAOMI_TTS: "._xiaomi",
    TTS_API: "._ttsapi",
    CAMB_TTS: "._cambtts",
    MOSS_TTS: "._mosstts",
}
_loaded_modules = {}


def _get_instance(name: int = 0):
    """
    获取模块，提取出里面的子类，并返回实例化对象
    """
    if name in _loaded_modules:
        return _loaded_modules[name]

    if name not in _module_map:
        raise AttributeError(f"No winform module named '{name}' found.")

    try:
        # 2. 动态导入模块
        module = importlib.import_module(_module_map[name], __name__)

        # 3. 使用 inspect 遍历模块里的所有类
        for obj_name, obj in inspect.getmembers(module, inspect.isclass):

            # 判断条件：
            # 1. 是 BaseWindow 的子类
            # 2. 不是 BaseWindow 本身
            # 3. 确实是写在这个文件里的（防止抓到 import 进来的其他子类）
            if issubclass(obj, BaseTTS) and obj is not BaseTTS and obj.__module__ == module.__name__:
                # 4. 找到目标类，存入缓存，并直接返回类（注意这里是 obj，没有括号！）
                _loaded_modules[name] = obj
                return obj

        # 如果遍历完没找到符合条件的类
        raise AttributeError(f"Module '{name}' contains no subclass of BaseWindow.")

    except ImportError as e:
        raise ImportError(f"Could not import winform module '{name}': {e}")


# 检查当前配音渠道是否支持所选配音语言
# 返回True为支持，其他为不支持并返回错误字符串
def is_allow_lang(langcode: str = None, tts_type: int = None):
    if langcode is None or tts_type is None:
        return True
    if tts_type == GPTSOVITS_TTS and langcode[:2] not in ['zh', 'ja', 'ko', 'en', 'yu']:
        return _ID_NAME_DICT.get(tts_type, '') + tr('Dubbing channel') + ' ' + tr('Only support') + tr(
            ['zh', 'ja', 'ko', 'en', 'yu'])
    # 中文、英文、日文、韩文、德文、法文、俄文、葡萄牙文、西班牙文、意大利文
    if tts_type == QWEN3LOCAL_TTS and langcode[:2] not in ['zh', 'ja', 'ko', 'en', 'yu', 'de', 'fr', 'ru', 'pt', 'es',
                                                           'it']:
        return _ID_NAME_DICT.get(tts_type, '') + tr('Dubbing channel') + ' ' + tr('Only support') + tr(
            ['zh', 'ja', 'ko', 'en', 'yu', 'de', 'fr', 'ru', 'pt', 'es', 'it'])

    if tts_type == CHATTTS and langcode[:2] not in ['zh', 'en']:
        return _ID_NAME_DICT.get(tts_type, '') + tr('Dubbing channel') + ' ' + tr('Only support') + tr(['zh', 'en'])
    if tts_type == Supertonic_TTS and langcode[:2] not in ['ko', 'en', 'es', 'pt', 'fr']:
        return _ID_NAME_DICT.get(tts_type, '') + tr('Dubbing channel') + ' ' + tr('Only support') + tr(
            ['ko', 'en', 'es', 'pt', 'fr'])

    return True


# 判断是否填写了相关配音渠道所需要的信息
# 正确返回True，失败返回False，并弹窗
def is_input_api(tts_type: int = None, return_str=False):
    _cls = _CLS_DICT.get(tts_type)
    if not _cls:
        return True
    if not params.get(_cls.get('key_name')):
        return "Please configure the SK or API information of the channel first." if return_str else winform.get_win(
            _cls.get("win"))
    return True


def clone_tips(tts_type, role: str = 'No', recogn_type=9):
    if tts_type in SUPPORT_CLONE and role == 'clone':
        return tr('clone_dubb_tips1') + (tr('clone_dubb_tips2') if recogn_type < 2 else '')
    return


# 统一调用 tts渠道入口，通过 tts_type 调用对应渠道
def run(*, queue_tts=None, language=None, uuid=None, play=False, is_test=False, tts_type=0, is_cuda=False) -> None:
    # 需要并行的数量3
    if len(queue_tts) < 1:
        return
    if app_cfg.exit_soft or (uuid and uuid in app_cfg.stoped_uuid_set):
        return

    kwargs = {
        "queue_tts": copy.deepcopy(queue_tts),
        "language": language,
        "uuid": uuid,
        "play": play,
        "is_test": is_test,
        "tts_type": tts_type,
        "is_cuda": is_cuda
    }

    _cls: Union[BaseTTS, None] = _get_instance(tts_type)
    if not _cls:
        raise RuntimeError(f'No this TTS Channel:{tts_type=}')

    return _cls(**kwargs).run()
