import os
import time
from dataclasses import dataclass
from pathlib import Path

import requests
from gradio_client import Client, handle_file
from videotrans.configure.config import tr, params, settings, app_cfg, logger, ROOT_DIR
from videotrans.configure._except import  StopRetry
from videotrans.tts._base import BaseTTS
from videotrans.util import tools


RETRY_NUMS = 2
RETRY_DELAY = 5


@dataclass
class CosyVoice(BaseTTS):
    def __post_init__(self):
        super().__post_init__()
        self.api_url = params.get('cosyvoice_url','').strip().rstrip('/').lower()
        self._add_internal_host_noproxy(self.api_url)
        self.rolelist = tools.get_f5tts_role()

    def _exec(self):
        self._local_mul_thread()

    def _item_task_cosyvoice2(self, data_item):

        text = data_item['text'].strip()
        if not text:
            return
        speed = 1.0
        try:
            speed = 1 + float(self.rate.replace('%', '')) / 100
        except ValueError:
            pass
        speed=max(0.5,min(2.0,speed))
        role = data_item['role']
        data = {'ref_wav': '','ref_text':data_item.get('ref_text','')}
        


        if role not in self.rolelist:
            raise StopRetry(tr('The role {} does not exist',role))
        if role == 'clone':
            data['ref_wav'] = data_item.get('ref_wav','')
            data['ref_text'] = data_item.get('ref_text','')
        else:
            data['ref_wav'] = ROOT_DIR+"/f5-tts/"+self.rolelist[role].get('ref_audio','')
            data['ref_text'] = self.rolelist[role].get('ref_text','')

        if not Path(data['ref_wav']).exists():
            raise StopRetry(f"{data['ref_wav']} is not exists")
        
        logger.debug(f'cosyvoice-tts {data=}')
        try:
            client = Client(self.api_url, ssl_verify=False)
        except Exception as e:
            raise StopRetry(str(e))
        # 参考音频对应文本内容
        prompt_text=data.get('ref_text','')
        print(f"{data['ref_wav']=}")
        # 提示词，克隆时放入参考音频文本中
        instruct_text=params.get('cosyvoice_instruct_text','')
        if instruct_text:
            prompt_text=f'You are a helpful assistant.{instruct_text}<|endofprompt|>{prompt_text}'
        result = client.predict(
            tts_text=text,
            mode_checkbox_group="3s极速复刻",
            prompt_wav_upload=handle_file(data['ref_wav']),
            prompt_wav_record=handle_file(data['ref_wav']),
            prompt_text=prompt_text,
            instruct_text=instruct_text,
            seed=0,
            stream=False,
            speed=speed,
            api_name="/generate_audio"

        )


        logger.debug(f'result={result}')
        wav_file = result[0] if isinstance(result, (list, tuple)) and result else result
        if isinstance(wav_file, dict) and "value" in wav_file:
            wav_file = wav_file['value']
        if isinstance(wav_file, str) and Path(wav_file).is_file():
            self.convert_to_wav(wav_file, data_item['filename'])
        else:
            raise RuntimeError(str(result))


    def _item_cosyvoice_api(self, data_item):
        if not data_item.get('text',''):
            return
        rate = float(self.rate.replace('%', '')) / 100 if self.rate else 0
        role = data_item['role']

        api_url = self.api_url
        data = {
            "text": data_item['text'],
            "lang": "zh" if self.language.startswith('zh') else self.language,
            "speed": 1 + rate
        }
        if role not in self.rolelist:
            raise StopRetry(tr('The preset role {} was not found in the configuration',role))
        if role == 'clone':
            # 克隆音色
            # 原项目使用 clone_mul 跨语种克隆的方案，实际测试效果不如同语种，这地方修改成同语种克隆 /clone_eq
            ref_wav_path = data_item.get("ref_wav",'')
            if not Path(ref_wav_path).exists():
                raise StopRetry(tr('No reference audio {} exists',ref_wav_path))

            data['reference_text'] = data_item.get('ref_text','')
            data['reference_audio'] = self._audio_to_base64(ref_wav_path)
            api_url += '/clone_eq'
            data['encode'] = 'base64'
        else:
            role_info = self.rolelist[role]
            data['reference_audio'] = ROOT_DIR+"/f5-tts/"+role_info.get('ref_audio','')

            if not data['reference_audio']:
                raise StopRetry(tr('Preset role {} is incorrectly configured, missing clone reference audio',role))

            # 检查是否存在参考文本，以决定使用哪个克隆接口
            reference_text = role_info.get('ref_text', '').strip()
            if reference_text:
                # 同时提供参考音频和文本，使用高质量同语种克隆
                data['reference_text'] = reference_text
                api_url += '/clone_eq'
            else:
                # 仅提供参考音频，使用跨语种克隆
                api_url += '/clone_mul'

        logger.debug(f'请求数据：{api_url=},{data=}')
        # 克隆声音
        response = requests.post(f"{api_url}", data=data,  timeout=3600)
        response.raise_for_status()

        # 如果是WAV音频流，获取原始音频数据
        with open(data_item['filename'] + ".wav", 'wb') as f:
            f.write(response.content)
        time.sleep(1)
        if not os.path.exists(data_item['filename'] + ".wav"):
            raise RuntimeError(tr('CosyVoice synthesis failed -2'))
        self.convert_to_wav(data_item['filename'] + ".wav", data_item['filename'])

    def _item_task(self, data_item,idx:int=-1):
        if self._exit() or  not data_item.get('text','').strip():
            return
        if self._exit() or tools.vail_file(data_item['filename']):
            return
        
        # 兼容之前的 cosyvoice-api 接口
        try:
            if ":9233" not in self.api_url:
                self._item_task_cosyvoice2(data_item)
            else:
                self._item_cosyvoice_api(data_item)

        except Exception as e:
            self.error=e
            raise