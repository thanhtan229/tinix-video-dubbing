def openwin():
    from PySide6 import QtWidgets
    from pathlib import Path
    from videotrans.configure.config import ROOT_DIR,tr,app_cfg,settings,params,TEMP_DIR,logger,defaulelang,HOME_DIR
    from videotrans.util import tools
    from videotrans.util.ListenVoice import ListenVoice
    def feed(d):
        if d == "ok":
            QtWidgets.QMessageBox.information(winobj, "ok", "Test Ok")
        else:
            tools.show_error(d)
        winobj.test.setText(tr('Test'))

    def test():
        url = winobj.api_url.text().strip()
        if not url.startswith('http'):
            url = 'http://' + url
        
        
        params["omnivoice_url"] = url

        
        params.save()

        _rolename = next(reversed(tools.get_f5tts_role().values()))
        if not isinstance(_rolename, dict):
            return tools.show_error(tr("No reference audio {} exists",_rolename))
        rolename = _rolename.get('ref_audio')
        file = ROOT_DIR + f'/f5-tts/{rolename}'
        if not Path(file).exists():
            return tools.show_error(tr("No reference audio {} exists", file))
        
        
        
        winobj.test.setText(tr('Testing...'))
        from videotrans import tts
        import time
        wk = ListenVoice(parent=winobj, queue_tts=[{
            "text": '你好啊我的朋友,希望你的每一天都美好愉快',
            "role":rolename,
            "filename": TEMP_DIR + f"/{time.time()}-omnivoice.wav",
            "tts_type": tts.OMNIVOICE_TTS}],
                         language="Auto",
                         tts_type=tts.OMNIVOICE_TTS)
        wk.uito.connect(feed)
        wk.start()

    def save():
        url = winobj.api_url.text().strip()
        if not url.startswith('http'):
            url = 'http://' + url

        params["omnivoice_url"] = url

        params.save()
        tools.set_process(text='omnivoice', type="refreshtts")

        winobj.close()

    from videotrans.component.set_form import OmniVoiceForm
    winobj = OmniVoiceForm()
    app_cfg.child_forms['omnivoice'] = winobj
    if params["omnivoice_url"]:
        winobj.api_url.setText(params["omnivoice_url"])

    winobj.save.clicked.connect(save)
    winobj.test.clicked.connect(test)
    winobj.show()
