import re
from dataclasses import dataclass, field
from typing import List, Union

from openai import OpenAI
from openai import LengthFinishReasonError
from videotrans.configure.config import tr,params,settings,app_cfg,logger
from videotrans.translator._base import BaseTrans
from videotrans.util import tools

RETRY_NUMS = 3
RETRY_DELAY = 5


@dataclass
class SILICONFLOW(BaseTrans):
    prompt: str = field(init=False)
    api_key: str = field(init=False)

    def __post_init__(self):
        super().__post_init__()
        self.model_name = params.get('guiji_model', '')
        self.api_url = "https://api.siliconflow.cn/v1"

        self.api_key = params.get('guiji_key', '')
        self.prompt = tools.get_prompt(ainame='siliconflow',aisendsrt=self.aisendsrt).replace('{lang}', self.target_language_name)

    def _item_task(self, data: Union[List[str], str]) -> str:
        if self._exit(): return
        text = "\n".join([i.strip() for i in data]) if isinstance(data, list) else data
        message = [
            {
                'role': 'system',
                'content':'You are a top-tier Subtitle Translation Engine.'},
            {
                'role': 'user',
                'content': self.prompt.replace('{batch_input}', f'{text}').replace('{context_block}',self.full_origin_subtitles)
            },
        ]

        model = OpenAI(api_key=self.api_key, base_url=self.api_url)

        response = model.chat.completions.create(
            model=self.model_name,
            messages=message,
            frequency_penalty=0,
            temperature=float(settings.get('aitrans_temperature',0.2)),
            max_tokens=int(params.get('guiji_max_tokens',8192))
        )

        logger.debug(f'[siliconflow]响应:{response=}')
        if not hasattr(response,'choices'):
            raise RuntimeError(str(response))
        if response.choices[0].finish_reason=='length':
            raise LengthFinishReasonError(completion=response)
        result = ""
        if response.choices[0].message.content:
            result = response.choices[0].message.content.strip()
        else:
            logger.warning(f'[siliconflow]请求失败:{response=}')
            raise RuntimeError(f"[SiliconFlow] {response.choices[0].finish_reason}:{response}")

        match = re.search(r'<TRANSLATE_TEXT>(.*?)</TRANSLATE_TEXT>', result, re.S)
        if match:
            return match.group(1)
        return result.strip()
