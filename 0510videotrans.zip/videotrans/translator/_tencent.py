import json
import logging
import os
from dataclasses import dataclass
from typing import List, Union

from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_not_exception_type, before_log, after_log
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.tmt.v20180321 import tmt_client, models

from videotrans.configure.config import tr,params,settings,app_cfg,logger
from videotrans.configure._except import NO_RETRY_EXCEPT
from videotrans.translator._base import BaseTrans

RETRY_NUMS = 3
RETRY_DELAY = 5


@dataclass
class Tencent(BaseTrans):

    def __post_init__(self):
        super().__post_init__()
        self.aisendsrt = False
        # 腾讯禁止国外ip
        os.environ["NO_PROXY"]="tmt.tencentcloudapi.com"


    @retry(retry=retry_if_not_exception_type(NO_RETRY_EXCEPT), stop=(stop_after_attempt(RETRY_NUMS)),
           wait=wait_fixed(RETRY_DELAY), before=before_log(logger, logging.INFO),
           after=after_log(logger, logging.INFO))
    def _item_task(self, data: Union[List[str], str]) -> str:
        if self._exit(): return
        cred = credential.Credential(params.get('tencent_SecretId', '').strip(),
                                     params.get('tencent_SecretKey',''))
        # 实例化一个http选项，可选的，没有特殊需求可以跳过
        httpProfile = HttpProfile(proxy="")
        httpProfile.endpoint = "tmt.tencentcloudapi.com"

        # 实例化一个client选项，可选的，没有特殊需求可以跳过
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        # 实例化要请求产品的client对象,clientProfile是可选的
        client = tmt_client.TmtClient(cred, "ap-beijing", clientProfile)

        reqdata = {
            "SourceText": "\n".join(data),
            "Source": 'zh' if self.source_code.lower() == 'zh-cn' else (self.source_code or 'auto'),
            "Target": 'zh' if self.target_code.lower() == 'zh-cn' else self.target_code,
            "ProjectId": 0,
        }
        if params.get('tencent_termlist',''):
            reqdata['TermRepoIDList'] = params.get('tencent_termlist','').split(',')

        req = models.TextTranslateRequest()

        req.from_json_string(json.dumps(reqdata))
        resp = client.TextTranslate(req)
        logger.debug(f'[腾讯]返回:{resp=}')
        return resp.TargetText.strip()
